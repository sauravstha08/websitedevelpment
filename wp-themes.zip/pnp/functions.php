<?php
/**
 * Pals and partners customizations
 *
 *
 * @package PNP
 * @since 1.0.0
 */

function astra_get_custom_button( $button_text = '', $button_link = '', $button_style = '' ) {

	$custom_html    = '';
	$button_classes = '';
	$button_text    = astra_get_option( $button_text );
	$button_link    = astra_get_option( $button_link );
	$button_style   = astra_get_option( $button_style );
	$outside_menu   = astra_get_option( 'header-display-outside-menu' );

	$button_classes = ( 'theme-button' === $button_style ? 'ast-button' : 'ast-custom-button' );

	$outside_menu_item = apply_filters( 'astra_convert_link_to_button', $outside_menu );

	global $current_user; wp_get_current_user();



	if ( '1' == $outside_menu_item ) {
		if( is_user_logged_in() ){
			$u_name = $current_user->display_name;
			$custom_html = '<a class="ast-custom-button-link" href="' . site_url("/my-account") . '"><button class=' . esc_attr( $button_classes ) . '>' . esc_attr( $current_user->display_name ) . '</button></a>';
		} else{
			$custom_html = '<a class="ast-custom-button-link" href="' . esc_url( do_shortcode( $button_link ) ) . '"><button class=' . esc_attr( $button_classes ) . '>' . esc_attr( do_shortcode( $button_text ) ) . '</button></a>';
		}
	} else {
		if( is_user_logged_in() ){
			$u_name = $current_user->display_name;
			$custom_html  = '<a class="ast-custom-button-link" href="' . esc_url( site_url("/my-account") ) . '"><button class=' . esc_attr( $button_classes ) . '>' . esc_attr( $current_user->display_name ) . '</button></a>';
			$custom_html .= '<a class="menu-link" href="' . esc_url( site_url("/my-account") ) . '">' . esc_attr( $current_user->display_name ) . '</a>';
		} else{
			$custom_html  = '<a class="ast-custom-button-link" href="' . esc_url( do_shortcode( $button_link ) ) . '"><button class=' . esc_attr( $button_classes ) . '>' . esc_attr( do_shortcode( $button_text ) ) . '</button></a>';
			$custom_html .= '<a class="menu-link" href="' . esc_url( do_shortcode( $button_link ) ) . '">' . esc_attr( do_shortcode( $button_text ) ) . '</a>';
		}
	}

	return $custom_html;
}


if ( ! function_exists( 'astra_get_prop' ) ) :

	/**
	 * Get a specific property of an array without needing to check if that property exists.
	 *
	 * 
	 */
	function astra_get_prop( $array, $prop, $default = null ) {

		if ( ! is_array( $array ) && ! ( is_object( $array ) && $array instanceof ArrayAccess ) ) {
			return $default;
		}

		if ( isset( $array[ $prop ] ) ) {
			$value = $array[ $prop ];
		} else {
			$value = '';
		}

		return empty( $value ) && null !== $default ? $default : $value;
	}

endif;


// echo apply_filters( 'wc_empty_cart_message', __( 'You have not selected any services.', 'woocommerce' ) ;	

function pnp_empty_service_message() {
    return "You have not selected any services";
}
add_filter( 'wc_empty_cart_message', 'pnp_empty_service_message', 10, 3 );